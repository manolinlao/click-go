import React from 'react';
import ReactDOM from 'react-dom';
import { ClickGoAppContainer } from './ClickGoAppContainer';

ReactDOM.render(
    <ClickGoAppContainer />,
    document.getElementById('root')
);
