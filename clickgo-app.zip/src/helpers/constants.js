export const constants = {
  NOK_TIMEOUT: 5000,
}